
package encantado.habilidades;

public interface Magico {

	void demostrarHabilidadMagica();

}
