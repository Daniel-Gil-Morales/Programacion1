
interface Prestable {
	
    void prestar();
    void devolver();
    boolean estaPrestado();
    
}